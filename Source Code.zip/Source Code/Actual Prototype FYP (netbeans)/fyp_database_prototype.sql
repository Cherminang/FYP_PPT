-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2023 at 08:35 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fyp_database_prototype`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `id` int(3) NOT NULL,
  `Article1` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Uploaded by` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Authored by` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Additional info` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `Article1`, `Uploaded by`, `Authored by`, `Additional info`) VALUES
(1, 'https://www.uxbooth.com/articles/the-difference-be', 'Eppe', 'Company', 'None');

-- --------------------------------------------------------

--
-- Table structure for table `audio`
--

CREATE TABLE `audio` (
  `id` int(3) NOT NULL,
  `Audio1` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Uploaded by` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Authored by` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Additional info` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `audio`
--

INSERT INTO `audio` (`id`, `Audio1`, `Uploaded by`, `Authored by`, `Additional info`) VALUES
(1, 'odb-05-25-23.mp3', 'Project management team', 'Peter Taylor', 'None');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(3) NOT NULL,
  `Image1` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Description` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `LINK` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `Image1`, `Description`, `LINK`) VALUES
(1, 'white_man.png', 'Duties and responsibilities of First Aider', 'PDF . 5mins . 20/05/2021'),
(2, 'osmosis learn pic2.jpg', 'The Balanced PMO', 'Audio . 4 mins . 21/05/2021'),
(3, 'osmosis learn pic3.jpg', 'When Waterfall Principles sneak back into Agile Workflows', 'Video . 3 mins . 10/05/2021'),
(4, 'osmosis pic4.JPG', 'Project management guide', 'Article . 9 mins . 8/05/2021'),
(9, '<iframe src=\"https://chat.openai.com/\"></iframe>', '<script>alert(document.cookie)</script>', '<script>alert(document.cookie)</script>'),
(10, 'white_man.png', 'test', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `Title` varchar(100) NOT NULL,
  `Authored by` varchar(50) NOT NULL,
  `Uploaded by` varchar(50) NOT NULL,
  `Additional info` varchar(50) NOT NULL,
  `audio` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `images` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `pdf` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `video` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`Title`, `Authored by`, `Uploaded by`, `Additional info`, `audio`, `images`, `pdf`, `video`) VALUES
('Sample content', 'GreenSafe', 'Poh Moi', '3 days', '', 'white_man.png', '', ''),
('Sample video', 'Us', 'Us', '3 days', '', '', '', 'https://www.youtube.com/embed/L229QDxDakU'),
('sample pdf', 'us', 'us', '6 days', '', '', 'pdf_doc_35pp.pdf', ''),
('sample audio', 'Laura Klein', 'Poh Moi', 'usersknow.com', 'odb-05-25-23.mp3', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `pdf`
--

CREATE TABLE `pdf` (
  `id` int(3) NOT NULL,
  `PDF1` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Uploaded by` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Authored by` varchar(50) NOT NULL,
  `Additional info` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pdf`
--

INSERT INTO `pdf` (`id`, `PDF1`, `Uploaded by`, `Authored by`, `Additional info`) VALUES
(1, 'pdf_doc_35pp.pdf', 'Poh Moi', 'Person', 'None');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(3) NOT NULL,
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `password` varchar(40) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `email` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `username`, `password`, `email`) VALUES
(1, 'Sneha', '928c3567f6f5ca5f3a0373c6f5a0e534babe3da8', 'sneha.v.nathan@gmail.com'),
(2, 'Sneha', 'Sneha123#', 'sneha.v.nathan@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE `video` (
  `id` int(3) NOT NULL,
  `Video1` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Uploaded by` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Authored by` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `Additional info` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`id`, `Video1`, `Uploaded by`, `Authored by`, `Additional info`) VALUES
(1, 'https://www.youtube.com/embed/hWV1HoSEQcw', 'Project Team', 'TECH in 5 mins', 'None');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `audio`
--
ALTER TABLE `audio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pdf`
--
ALTER TABLE `pdf`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `audio`
--
ALTER TABLE `audio`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pdf`
--
ALTER TABLE `pdf`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
